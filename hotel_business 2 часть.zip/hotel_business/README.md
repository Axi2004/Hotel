# Hotel Managment System

This project is a hotel managment system built with Django.

## Installation

1. Close the repository:
```bash
git clone https://github.com/Axi2004/hotel.git
