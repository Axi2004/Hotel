from django.contrib import admin

def register_custom_user():
    from .models import CustomUser
    admin.site.register(CustomUser)

register_custom_user()
