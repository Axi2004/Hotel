from django.apps import AppConfig
from django.contrib import admin
from django.apps import apps

#class HotelConfig(AppConfig):
 #   name = 'hotel'

  #  def ready(self):

   #     from .models import CustomUser
    #    admin.site.register(CustomUser)