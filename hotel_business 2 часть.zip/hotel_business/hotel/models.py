from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    RALE_CHOICES = (
        ('admin', 'Администратор'),
        ('manager', 'Менеджер'),
        ('client', 'Клиент'),
    )
    role = models.CharField(max_length=20, choices=RALE_CHOICES, default='client')
    email = models.EmailField(unique=True)

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"

    class Meta:
        verbose_name = "Пользователь"
        verbose_name_plural = "Пользователи"


class Document(models.Model):
    series = models.CharField(max_length=50, verbose_name="Серия")
    number = models.CharField(max_length=50, verbose_name="Номер")
    issue_date = models.DateField(verbose_name="Дата выдачи")
    issued_by = models.CharField(max_length=100, verbose_name="Кем выдан")

    def __str__(self):
        return f"{self.series} {self.number}"

    class Meta:
        verbose_name = "Документ"
        verbose_name_plural = "Документы"


class Guest(models.Model):
    full_name = models.CharField(max_length=255, default='Не указано', verbose_name="ФИО")
    phone_number = models.CharField(max_length=20, blank=True, verbose_name="Телефон")
    birth_date = models.DateField(default="2000-01-01", verbose_name="Дата рождения")
    document = models.ForeignKey(
        Document,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Документ"
    )
    discount = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=0.00,
        verbose_name="Скидка (%)"
    )

    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = "Гость"
        verbose_name_plural = "Гости"


class Category(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название категории")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена за сутки")
    description = models.TextField(blank=True, verbose_name="Описание")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Категория номера"
        verbose_name_plural = "Категории номеров"


class Room(models.Model):
    floor = models.IntegerField(default=1, verbose_name="Этаж")
    room_number = models.CharField(max_length=10, unique=True, verbose_name="Номер комнаты")
    bed_count = models.IntegerField(default=1, verbose_name="Количество кроватей")
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        verbose_name="Категория"
    )

    def __str__(self):
        return f"Комната {self.room_number} (этаж {self.floor})"

    class Meta:
        verbose_name = "Номер"
        verbose_name_plural = "Номера"


class Item(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название оборудования")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Предмет оборудования"
        verbose_name_plural = "Предметы оборудования"


class Equipment(models.Model):
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        verbose_name="Категория номера"
    )
    item = models.ForeignKey(
        Item,
        on_delete=models.CASCADE,
        verbose_name="Оборудование"
    )

    def __str__(self):
        return f"{self.item.name} → {self.category.name}"

    class Meta:
        verbose_name = "Оснащение категории"
        verbose_name_plural = "Оснащение категорий"
        unique_together = ('category', 'item')


class Reservation(models.Model):
    guest = models.ForeignKey(Guest, on_delete=models.CASCADE, verbose_name="Гость")
    room = models.ForeignKey(Room, on_delete=models.CASCADE, verbose_name="Номер")
    check_in_date = models.DateField(verbose_name="Дата заезда")
    check_out_date = models.DateField(verbose_name="Дата выезда")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Стоимость")
    paid = models.BooleanField(default=False, verbose_name="Оплачено")

    def __str__(self):
        return f"Бронь #{self.id} — {self.guest.full_name}"

    class Meta:
        verbose_name = "Бронирование"
        verbose_name_plural = "Бронирования"


class Service(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название услуги")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена")
    description = models.TextField(blank=True, verbose_name="Описание")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Услуга"
        verbose_name_plural = "Услуги"


class ServiceProvision(models.Model):
    reservation = models.ForeignKey(
        Reservation,
        on_delete=models.CASCADE,
        verbose_name="Бронирование"
    )
    service = models.ForeignKey(
        Service,
        on_delete=models.CASCADE,
        verbose_name="Услуга"
    )
    quantity = models.PositiveIntegerField(default=1, verbose_name="Количество")
    service_date = models.DateField(verbose_name="Дата оказания")

    def __str__(self):
        return f"{self.service.name} ×{self.quantity} для брони #{self.reservation.id}"

    class Meta:
        verbose_name = "Оказанная услуга"
        verbose_name_plural = "Оказанные услуги"