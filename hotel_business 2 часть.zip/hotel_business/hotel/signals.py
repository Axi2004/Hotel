from django.db.models.signals import ready
from django.apps import AppConfig
from django.contrib import admin
from .models import CustomUser

def register_custom_user(sender, **kwargs):
    admin.site.register(CustomUser)

class HotelConfig(AppConfig):
    name = 'hotel.signals'

    def ready(self):
        import hotel.signals
        ready.connect(register_custom_user, sender=self)