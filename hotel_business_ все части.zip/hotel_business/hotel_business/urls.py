# hotel_business/urls.py
from django.contrib import admin
from django.urls import path
from hotel import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('guest/services/', views.guest_services, name='guest_services'),
    # Главная → авторизация
    path('', views.login_view, name='login'),

    # Явный маршрут для гостей
    path('services/', views.services_list, name='services_list'),

    # Выход
    path('logout/', views.logout_view, name='logout'),

    # Функции менеджера
    path('manager/clients/', views.client_list, name='client_list'),
    path('manager/services/', views.manager_services, name='manager_services'),
    path('manager/rooms/', views.room_list, name='room_list'),
    path('manager/book/', views.book_client, name='book_client'),
]