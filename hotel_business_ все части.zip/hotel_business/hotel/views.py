from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import CustomUser, Service, Room, ClientServiceBooking
from django.db import migrations
from functools import wraps
from .models import CustomUser
from django.contrib.auth.decorators import login_required


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # ВСЕГДА перенаправляем на список услуг — как требует Часть 2
            return redirect('services_list')
        else:
            messages.error(request, "Неверное имя пользователя или пароль.")

    return render(request, 'login.html')

def guest_services(request):
    services = Service.objects.all()
    return render(request, 'guest_services.html', {'services': services})

def services_list(request):
    services = Service.objects.all()
    user = request.user
    rendered_services = []

    for s in services:
        item = {
            'service': s,
            'show_discount': False,
            'final_price': None,
            'high_discount': False,
        }
        if user.is_authenticated and hasattr(user, 'role') and user.role == 'client' and s.is_available and user.discount > 0:
            item['show_discount'] = True
            item['final_price'] = float(s.price) * (1 - float(user.discount) / 100)
            if user.discount > 10:
                item['high_discount'] = True

        rendered_services.append(item)

    return render(request, 'services_list.html', {
        'rendered_services': rendered_services,
        'user': user,
    })

def home_redirect(request):
    return redirect('login')

def add_default_services(apps, schema_editor):
    Service = apps.get_model('hotel', 'Service')
    services = [
        {"name": "Завтрак", "description": "Континентальный завтрак", "price": 500.00, "is_available": True},
        {"name": "Уборка номера", "description": "Ежедневная уборка", "price": 300.00, "is_available": True},
        {"name": "Спа", "description": "Массаж и процедуры", "price": 2000.00, "is_available": False},
        {"name": "Трансфер", "description": "Из аэропорта", "price": 1500.00, "is_available": True},
    ]
    for srv in services:
        Service.objects.get_or_create(
            name=srv["name"],
            defaults={
                "description": srv["description"],
                "price": srv["price"],
                "is_available": srv["is_available"]
            }
        )

def remove_default_services(apps, schema_editor):
    Service = apps.get_model('hotel', 'Service')
    Service.objects.filter(name__in=[
        "Завтрак", "Уборка номера", "Спа", "Трансфер"
    ]).delete()

class Migration(migrations.Migration):
    dependencies = [
        ('hotel', '0001_initial'),  # ← Убедись, что это актуальная предыдущая миграция
    ]

    operations = [
        migrations.RunPython(add_default_services, reverse_code=remove_default_services),
    ]

def manager_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, "Требуется авторизация.")
            return redirect('login')
        if request.user.role != 'manager':
            messages.error(request, "Доступ разрешён только менеджеру.")
            return redirect('services_list')
        return view_func(request, *args, **kwargs)
    return wrapper

@manager_required
def client_list(request):
    clients = CustomUser.objects.filter(role='client').order_by('full_name')  # ← сортировка по ФИО (для Части 4)
    return render(request, 'client_list.html', {'clients': clients})

@manager_required
def manager_services(request):
    query = request.GET.get('q', '').strip()
    services = Service.objects.all()
    if query:
        services = services.filter(name__icontains=query)
    return render(request, 'manager_services.html', {
        'services': services,
        'query': query
    })

@manager_required
def room_list(request):
    rooms = Room.objects.all()
    bed_count = request.GET.get('bed_count')   # строка
    category = request.GET.get('category')     # строка

    if bed_count:
        rooms = rooms.filter(bed_count=bed_count)  # Django автоматически преобразует строку в int
    if category:
        rooms = rooms.filter(category=category)

    # Преобразуем bed_counts в строки для сравнения в шаблоне
    bed_counts = [
        str(b) for b in Room.objects.values_list('bed_count', flat=True).distinct().order_by('bed_count')
    ]
    categories = Room.objects.values_list('category', flat=True).distinct()

    return render(request, 'room_list.html', {
        'rooms': rooms,
        'bed_counts': bed_counts,          # теперь строки
        'categories': categories,
        'current_bed': bed_count,          # строка
        'current_cat': category,           # строка
    })

@manager_required
def book_client(request):
    clients = CustomUser.objects.filter(role='client')
    services = Service.objects.filter(is_available=True)

    if request.method == 'POST':
        client_id = request.POST.get('client')
        service_id = request.POST.get('service')

        if client_id and service_id:
            client = CustomUser.objects.get(id=client_id, role='client')
            service = Service.objects.get(id=service_id, is_available=True)

            if ClientServiceBooking.objects.filter(client=client, service=service).exists():
                messages.warning(request, "Клиент уже записан на эту услугу.")
            else:
                ClientServiceBooking.objects.create(client=client, service=service)
                messages.success(request, f"Клиент {client.full_name} успешно записан на услугу «{service.name}».")
            return redirect('book_client')

    return render(request, 'book_client.html', {
        'clients': clients,
        'services': services
    })

def logout_view(request):
    logout(request)
    messages.info(request, "Вы успешно вышли из системы.")
    return redirect('services_list')