from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager

class Document(models.Model):
    """
    Таблица документов (паспорт, водительское удостоверение и т.д.)
    """
    series = models.CharField(max_length=10, verbose_name="Серия")
    number = models.CharField(max_length=20, verbose_name="Номер")
    issue_date = models.DateField(verbose_name="Дата выдачи")
    issued_by = models.CharField(max_length=255, verbose_name="Кем выдан")

    def __str__(self):
        return f"{self.series} {self.number}"

class Guest(models.Model):
    """
    Гость гостиницы. Связан с документом и может иметь скидку.
    """
    full_name = models.CharField(max_length=255, verbose_name="ФИО")
    phone_number = models.CharField(max_length=20, verbose_name="Номер телефона")
    birth_date = models.DateField(verbose_name="Дата рождения")
    document = models.ForeignKey(Document, on_delete=models.CASCADE, verbose_name="Документ")
    discount = models.DecimalField(max_digits=5, decimal_places=2, default=0.00, verbose_name="Скидка (%)")

    def __str__(self):
        return self.full_name

class Category(models.Model):
    """
    Категория номера (Стандарт, Комфорт, Люкс и т.д.)
    """
    name = models.CharField(max_length=100, verbose_name="Название")
    price_per_night = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена за ночь")
    description = models.TextField(blank=True, verbose_name="Описание")

    def __str__(self):
        return self.name

class Room(models.Model):
    CATEGORY_CHOICES = [
        ('standard', 'Стандарт'),
        ('comfort', 'Комфорт'),
        ('luxury', 'Люкс'),
    ]
    room_number = models.CharField(max_length=10, unique=True)
    bed_count = models.PositiveIntegerField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)

    def __str__(self):
        return f"Номер {self.room_number}"

class Service(models.Model):
    """
    Услуга гостиницы (завтрак, уборка, трансфер и т.д.)
    """
    name = models.CharField(max_length=255, verbose_name="Название")
    description = models.TextField(blank=True, verbose_name="Описание")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена")
    is_available = models.BooleanField(default=True, verbose_name="Доступна")

    def __str__(self):
        return self.name

class Booking(models.Model):
    """
    Бронирование номера гостем.
    """
    guest = models.ForeignKey(Guest, on_delete=models.CASCADE, verbose_name="Клиент")
    room = models.ForeignKey(Room, on_delete=models.CASCADE, verbose_name="Номер")
    check_in_date = models.DateField(verbose_name="Дата заезда")
    check_out_date = models.DateField(verbose_name="Дата выезда")
    total_cost = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Стоимость")
    is_paid = models.BooleanField(default=False, verbose_name="Оплачено")

    def __str__(self):
        return f"Бронь {self.guest.full_name} - {self.room.room_number}"

class ServiceProvision(models.Model):
    """
    Оказание услуги клиенту в рамках бронирования.
    """
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, verbose_name="Бронирование")
    service = models.ForeignKey(Service, on_delete=models.CASCADE, verbose_name="Услуга")
    quantity = models.IntegerField(default=1, verbose_name="Количество")
    provision_date = models.DateField(verbose_name="Дата оказания услуги")

    def __str__(self):
        return f"{self.service.name} для {self.booking.guest.full_name}"

class Item(models.Model):
    """
    Предмет оснащения номера (телевизор, холодильник и т.д.)
    """
    name = models.CharField(max_length=255, verbose_name="Название")

    def __str__(self):
        return self.name

class RoomEquipment(models.Model):
    """
    Связь между номером и предметом оснащения (ManyToMany).
    """
    room = models.ForeignKey(Room, on_delete=models.CASCADE, verbose_name="Номер")
    bed_count = models.PositiveIntegerField()
    category = models.CharField(max_length=20, choices=[
        ('standard', 'Стандарт'),
        ('comfort', 'Комфорт'),
        ('luxury', 'Люкс'),
    ])
    item = models.ForeignKey(Item, on_delete=models.CASCADE, verbose_name="Предмет")

    class Meta:
        unique_together = ('room', 'item')

    def __str__(self):
        return f"{self.room} - {self.item}"

class CustomUserManager(BaseUserManager):
    def create_user(self, username, password=None, **extra_fields):
        if not username:
            raise ValueError("Необходимо указать имя пользователя")
        user = self.model(username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password=None, **extra_fields):
        extra_fields.setdefault('role', 'admin')
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(username, password, **extra_fields)

class CustomUser(AbstractBaseUser, PermissionsMixin):
    """
    Кастомная модель пользователя с поддержкой ролей.
    """
    ROLE_CHOICES = [
        ('admin', 'Администратор'),
        ('manager', 'Менеджер'),
        ('client', 'Клиент'),
        ('guest', 'Гость'),
    ]

    username = models.CharField(max_length=150, unique=True, verbose_name="Логин")
    full_name = models.CharField(max_length=255, blank=True, verbose_name="ФИО")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Телефон")
    discount = models.DecimalField(max_digits=5, decimal_places=2, default=0.00, verbose_name="Скидка (%)")
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='guest', verbose_name="Роль")
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = CustomUserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = []

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"

class ClientServiceBooking(models.Model):
    client = models.ForeignKey(CustomUser, on_delete=models.CASCADE, limit_choices_to={'role': 'client'})
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    booking_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.client.full_name} — {self.service.name}"