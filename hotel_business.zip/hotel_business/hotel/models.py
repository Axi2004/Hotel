from django.db import models

class Document(models.Model):
    document_id = models.AutoField(primary_key=True)
    series = models.CharField(max_length=50)
    number = models.CharField(max_length=50)
    issue_date = models.DateField()
    issued_by = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.series} {self.number}"

class Guest(models.Model):
    full_name = models.CharField(max_length=255, default='Unknown')
    phone_number = models.CharField(max_length=20, default="")
    birth_date = models.DateField(default="2000-01-01")
    document = models.ForeignKey(Document, on_delete=models.CASCADE, null=True, blank=True)
    discount = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)

    def __str__(self):
        return self.full_name

class Category(models.Model):
    category_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()

    def __str__(self):
        return self.name

class Room(models.Model):
    floor = models.IntegerField(default=1)
    room_count = models.IntegerField(default=1)
    bed_count = models.IntegerField(default=0)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)

    def __str__(self):
        return f"Room {self.room_id}"

class Item(models.Model):
    item_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Equipment(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.category} - {self.item}"

class Reservation(models.Model):
    reservation_id = models.AutoField(primary_key=True)
    guest = models.ForeignKey(Guest, on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    check_in_date = models.DateField()
    check_out_date = models.DateField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    paid = models.BooleanField(default=False)

    def __str__(self):
        return f"Reservation {self.reservation_id}"

class Service(models.Model):
    service_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()

    def __str__(self):
        return self.name

class ServiceProvision(models.Model):
    service_provision_id = models.AutoField(primary_key=True)
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE)
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    service_date = models.DateField()

    def __str__(self):
        return f"Service {self.service.name} for reservation {self.reservation.reservation_id}"